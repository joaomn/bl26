// ============================================================
//  DATA.JS — Edite aqui para cada novo jogo
//  Adicione participantes na lista PARTICIPANTS
//  Adicione jogos na lista GAMES
// ============================================================

// ------------------------------------------------------------------
// PARTICIPANTES AUTORIZADOS
// Adicione o e-mail de cada pessoa que pagou.
// Você (organizador) já está incluído por padrão.
// ------------------------------------------------------------------
const PARTICIPANTS = [
  // Organizador
  { name: "João (organizador)", email: "joaoaraujomn@gmail.com", isAdmin: true },

  // Participantes — adicione abaixo conforme forem pagando:
  // { name: "Fulano Silva",   email: "fulano@email.com" },
  // { name: "Ciclana Santos", email: "ciclana@email.com" },
];

// ------------------------------------------------------------------
// JOGOS DO BOLÃO
// Para adicionar um novo jogo:
//   1. Crie a aba no seu Google Sheets com as apostas
//   2. Copie o link público de compartilhamento (modo leitura)
//   3. Adicione um objeto novo aqui na lista abaixo
//
// status: "upcoming" | "open" | "closed" | "finished"
// sheetUrl: link direto para a aba da planilha (ou null se ainda não publicada)
// result: null enquanto não jogar, "3x1" depois por exemplo
// ------------------------------------------------------------------
const GAMES = [
  {
    id: "jogo1",
    phase: "Fase de Grupos",
    phaseTag: "grupos",
    homeTeam: { name: "Brasil",   flag: "🇧🇷" },
    awayTeam: { name: "Marrocos", flag: "🇲🇦" },
    date: "2026-06-17",
    time: "18:00",
    venue: "MetLife Stadium, Nova Jersey",
    status: "open",         // "open" = apostas abertas | "closed" = encerradas | "finished" = resultado disponível
    result: null,           // Ex.: { home: 2, away: 1 } quando o jogo terminar
    sheetUrl: "https://docs.google.com/spreadsheets/d/1pQj41Q9G6JKYnyzbf3pjztmFBfWNaI0bQe9kmzaZNyo/edit?usp=sharing",
    betDeadline: "2026-06-17T18:59:00",
    prizeInfo: "R$ 20,00 por participante · Acumula se ninguém acertar",
  },

  // ------------------------------------------------------------------
  // MODELO PARA PRÓXIMOS JOGOS — copie e edite:
  // ------------------------------------------------------------------
  // {
  //   id: "jogo2",
  //   phase: "Fase de Grupos",
  //   phaseTag: "grupos",
  //   homeTeam: { name: "Brasil",    flag: "🇧🇷" },
  //   awayTeam: { name: "Espanha",   flag: "🇪🇸" },
  //   date: "2026-06-22",
  //   time: "15:00",
  //   venue: "SoFi Stadium, Los Angeles",
  //   status: "upcoming",
  //   result: null,
  //   sheetUrl: null,
  //   betDeadline: "2026-06-22T14:59:00",
  //   prizeInfo: "R$ 20,00 por participante · Acumula se ninguém acertar",
  // },
];
