// ============================================================
//  APP.JS — Lógica da aplicação
// ============================================================

const STORAGE_KEY = "bolao_user_email";

// ---------- HELPERS ----------

function findParticipant(email) {
  const normalized = email.trim().toLowerCase();
  return PARTICIPANTS.find(p => p.email.trim().toLowerCase() === normalized) || null;
}

function formatDate(dateStr) {
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function formatDeadline(isoStr) {
  const dt = new Date(isoStr);
  return dt.toLocaleString("pt-BR", {
    day: "2-digit", month: "2-digit",
    hour: "2-digit", minute: "2-digit",
  });
}

function isDeadlinePassed(isoStr) {
  return new Date() > new Date(isoStr);
}

function statusLabel(status, deadline) {
  if (status === "finished") return { text: "Encerrado", cls: "badge-finished" };
  if (status === "closed" || isDeadlinePassed(deadline)) return { text: "Apostas fechadas", cls: "badge-closed" };
  if (status === "open")   return { text: "Apostas abertas", cls: "badge-open" };
  return { text: "Em breve", cls: "badge-upcoming" };
}

// ---------- TICKER ----------

function buildTicker() {
  const track = document.getElementById("ticker-track");
  const items = GAMES.map(g => {
    const result = g.result
      ? `${g.homeTeam.flag} ${g.homeTeam.name} ${g.result.home} × ${g.result.away} ${g.awayTeam.name} ${g.awayTeam.flag}`
      : `${g.homeTeam.flag} ${g.homeTeam.name} × ${g.awayTeam.name} ${g.awayTeam.flag} — ${formatDate(g.date)}`;
    return `<span class="ticker-item">${items ? "  ·  " : ""}${result}</span>`;
  });
  // duplicate for seamless loop
  const html = items.join("  <span class='ticker-sep'>|</span>  ");
  track.innerHTML = html + "  <span class='ticker-sep'>|</span>  " + html;
}

// ---------- PHASE FILTERS ----------

let activePhase = "all";

function buildFilters() {
  const container = document.getElementById("phase-filters");
  const phases = ["all", ...new Set(GAMES.map(g => g.phaseTag))];
  const labels = { all: "Todos" };
  GAMES.forEach(g => { labels[g.phaseTag] = g.phase; });

  container.innerHTML = phases.map(ph => `
    <button class="filter-btn ${ph === activePhase ? "active" : ""}" data-phase="${ph}">
      ${labels[ph]}
    </button>
  `).join("");

  container.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      activePhase = btn.dataset.phase;
      buildFilters();
      buildGames();
    });
  });
}

// ---------- GAMES ----------

function buildGames() {
  const section = document.getElementById("games-section");
  const filtered = activePhase === "all"
    ? GAMES
    : GAMES.filter(g => g.phaseTag === activePhase);

  if (filtered.length === 0) {
    section.innerHTML = `<div class="empty-state">Nenhum jogo nesta fase ainda.</div>`;
    return;
  }

  section.innerHTML = filtered.map(game => {
    const { text, cls } = statusLabel(game.status, game.betDeadline);
    const hasSheet = !!game.sheetUrl && (game.status === "closed" || game.status === "finished" || isDeadlinePassed(game.betDeadline));
    const resultHtml = game.result
      ? `<div class="game-result">${game.result.home} <span class="result-x">×</span> ${game.result.away}</div>`
      : `<div class="game-result pending">? <span class="result-x">×</span> ?</div>`;

    return `
      <div class="game-card" data-id="${game.id}">
        <div class="game-card-header">
          <span class="badge ${cls}">${text}</span>
          <span class="game-phase-label">${game.phase}</span>
        </div>

        <div class="game-matchup">
          <div class="team">
            <span class="team-flag">${game.homeTeam.flag}</span>
            <span class="team-name">${game.homeTeam.name}</span>
          </div>
          ${resultHtml}
          <div class="team">
            <span class="team-flag">${game.awayTeam.flag}</span>
            <span class="team-name">${game.awayTeam.name}</span>
          </div>
        </div>

        <div class="game-meta">
          <span>📅 ${formatDate(game.date)} às ${game.time}</span>
          <span>📍 ${game.venue}</span>
        </div>

        <div class="game-prize">
          💰 ${game.prizeInfo}
        </div>

        <div class="game-deadline">
          ⏰ Apostas até: <strong>${formatDeadline(game.betDeadline)}</strong>
        </div>

        <div class="game-actions">
          ${hasSheet
            ? `<a class="btn-sheet" href="${game.sheetUrl}" target="_blank" rel="noopener">
                📊 Ver apostas
              </a>`
            : `<span class="btn-sheet disabled">📊 Apostas disponíveis após o encerramento</span>`
          }
        </div>
      </div>
    `;
  }).join("");
}

// ---------- LOGIN ----------

function doLogin() {
  const input = document.getElementById("email-input");
  const error = document.getElementById("email-error");
  const email = input.value.trim();

  if (!email) {
    error.textContent = "Digite seu e-mail.";
    input.focus();
    return;
  }

  const participant = findParticipant(email);
  if (!participant) {
    error.textContent = "E-mail não encontrado. Verifique se se inscreveu e pagou.";
    input.classList.add("input-shake");
    setTimeout(() => input.classList.remove("input-shake"), 500);
    return;
  }

  // Salva sessão
  sessionStorage.setItem(STORAGE_KEY, email);
  enterApp(participant);
}

function enterApp(participant) {
  document.getElementById("login-screen").classList.remove("active");
  document.getElementById("app-screen").classList.add("active");
  document.getElementById("user-badge").textContent = `👤 ${participant.name}`;

  buildTicker();
  buildFilters();
  buildGames();
}

function doLogout() {
  sessionStorage.removeItem(STORAGE_KEY);
  document.getElementById("app-screen").classList.remove("active");
  document.getElementById("login-screen").classList.add("active");
  document.getElementById("email-input").value = "";
  document.getElementById("email-error").textContent = "";
}

// ---------- INIT ----------

document.addEventListener("DOMContentLoaded", () => {
  // Tenta sessão salva
  const saved = sessionStorage.getItem(STORAGE_KEY);
  if (saved) {
    const participant = findParticipant(saved);
    if (participant) {
      enterApp(participant);
    }
  }

  document.getElementById("login-btn").addEventListener("click", doLogin);
  document.getElementById("logout-btn").addEventListener("click", doLogout);

  document.getElementById("email-input").addEventListener("keydown", e => {
    if (e.key === "Enter") doLogin();
  });
});
