# 🏆 Bolão.Cup — Guia de uso

## Estrutura dos arquivos

```
bolao/
├── index.html   → página principal (não precisa editar)
├── style.css    → estilos (não precisa editar)
├── app.js       → lógica (não precisa editar)
└── data.js      → ⭐ EDITE AQUI para cada jogo novo
```

---

## Como adicionar um participante

Abra `data.js` e adicione na lista `PARTICIPANTS`:

```js
{ name: "Fulano Silva", email: "fulano@email.com" },
```

---

## Como adicionar um novo jogo

Copie o bloco comentado em `data.js` e edite:

```js
{
  id: "jogo2",                          // ID único, sem espaços
  phase: "Fase de Grupos",              // Nome da fase (aparece no filtro)
  phaseTag: "grupos",                   // Tag interna (sem acentos, sem espaços)
  homeTeam: { name: "Brasil",  flag: "🇧🇷" },
  awayTeam: { name: "Espanha", flag: "🇪🇸" },
  date: "2026-06-22",                   // Formato YYYY-MM-DD
  time: "15:00",                        // Horário de Brasília
  venue: "SoFi Stadium, Los Angeles",
  status: "upcoming",                   // upcoming | open | closed | finished
  result: null,                         // null ou { home: 2, away: 1 }
  sheetUrl: null,                       // link da planilha (null = botão desativado)
  betDeadline: "2026-06-22T14:59:00",   // Prazo ISO (horário local do servidor)
  prizeInfo: "R$ 20,00 por participante · Acumula se ninguém acertar",
},
```

### Status do jogo

| status       | o que aparece                          |
|--------------|----------------------------------------|
| `upcoming`   | "Em breve" (cinza azulado)             |
| `open`       | "Apostas abertas" (verde)              |
| `closed`     | "Apostas fechadas" (amarelo)           |
| `finished`   | "Encerrado" + resultado                |

> O botão "Ver apostas" só aparece quando o prazo passou OU status é `closed`/`finished`.

### Registrar resultado

```js
result: { home: 3, away: 1 },
status: "finished",
```

---

## Deploy no Vercel

1. Crie uma conta em [vercel.com](https://vercel.com)
2. Coloque os 4 arquivos numa pasta no GitHub (repositório público ou privado)
3. No Vercel, clique em "Add New → Project" e importe o repositório
4. Clique em Deploy — pronto!

Para atualizar: edite `data.js` no GitHub e o Vercel publica automaticamente.

---

## Segurança

O login é **proteção visual** (client-side). Os e-mails ficam em `data.js`.  
Para um bolão entre amigos, é mais que suficiente.  
Se quiser proteção real, a próxima evolução é um backend simples (Node/Vercel Functions).
